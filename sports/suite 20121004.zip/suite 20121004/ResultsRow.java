import java.text.DecimalFormat;
import java.text.NumberFormat;

public class ResultsRow {

	NumberFormat format = new DecimalFormat("###.##");

	String headerString = 
			(		"pft," 			+
					"pct,"	 		+
					"n," 			+
					"IOS," 			+
					"nTPG," 		+
					"decay,"		+
					"ssn,"			+
					"nrDA,"		 	+
					"ndDA," 		+
					"pMin," 		+
					"pMax," 		+
					"dbMin," 		+
					"dbMax," 		+
					"daMin," 		+
					"daMax," 		);

	double	pft;
	double 	pct;
	int		n;
	boolean ios;
	int		nTPG;
	String	decay;
	int		ssn;
	int		nrDA;
	int		ndDA;
	double	pMin;
	double	pMax;
	double 	dbMin;
	double	dbMax;
	double	daMin;
	double	daMax;

	public ResultsRow(){}

	public ResultsRow(boolean _ios, int _nTPG, String _decay, int _ssn, int _nrDA, int _ndDA, double _pMin, double _pMax, double _dbMin, double _dbMax, double _daMin, double _daMax, int _n, double _pct, double _pft){

		pft  	 = _pft;
		pct  	 = _pct;
		n    	 = _n;    
		ios   	 = _ios;   
		nTPG  	 = _nTPG;  
		decay 	 = _decay; 
		ssn		 = _ssn;
		nrDA  	 = _nrDA;  
		ndDA  	 = _ndDA;  
		pMin 	 = _pMin; 
		pMax 	 = _pMax; 
		dbMin	 = _dbMin;
		dbMax	 = _dbMax;
		daMin	 = _daMin;
		daMax	 = _daMax;
	}

	public String toOutputString() {
		return 	
				format.format(pft)      +","+  
				format.format(pct) 	    +","+
				n    	              	+","+ 
				ios   	 				+","+ 
				nTPG  	                +","+ 
				decay.substring(0, 3) 	+","+  
				ssn						+","+
				nrDA  	                +","+ 
				ndDA  	                +","+ 
				pMin 	                +","+ 
				pMax 	                +","+
				dbMin	                +","+ 
				dbMax	                +","+ 
				daMin	                +","+ 
				daMax;	 
	}
}

