

makePrettyPvalsTable <- function(){		
	namesAndPvals = as.matrix(summary(model)$coefficients[,"Pr(>|t|)"])																				#do all this crap to format the team names and pvalues into a single dataframe:		
	pVals = as.numeric(format(namesAndPvals, digits = 4))
	for (i in seq_along(row.names(namesAndPvals)))	
		row.names(namesAndPvals)[i] = substr(row.names(namesAndPvals)[i], 19, nchar(row.names(namesAndPvals)[i]))		
	namesAndPvals <- data.frame( row.names(namesAndPvals), namesAndPvals[,1])																#namesAndPvals = namesAndPvals[!duplicated(namesAndPvals[,1]),]														# commented cuz i want both sets of pvalues.  for x vs y teams.  for model w/ no intercept, i should use the 2nd p's i thikn
	namesAndPvals = namesAndPvals[2:nrow(namesAndPvals),]	
	names(namesAndPvals) <- c("team", "pVal")
	namesAndPvals <- data.frame(namesAndPvals$team, namesAndPvals$pVal)
	names(namesAndPvals) <- c("team", "pVal")			
	return(namesAndPvals)
}
recordPValues <- function(p_x_i, p_y_i){		
	for (r in indicesOfCurrentDate) {																										# now lets go through the rows of the current day and fill in their pvals one by one		
		xTeamName = format(dCharM[r, "x_name"])																										#get x and y team names for row r, to match the pvals in namesAndPvals
		yTeamName = format(dCharM[r, "y_name"])			
		pValsRowsWithTeamX = which(namesAndPvals$team == xTeamName)
		pValsRowsWithTeamY = which(namesAndPvals$team == yTeamName)
		
		if (length(pValsRowsWithTeamX) > 0) { 	teamXpVal = namesAndPvals$pVal[pValsRowsWithTeamX[1]]								#if a team isn't listed in the glm model summary, it might be because it's the first team.  so it gets left off the coefficients/p-values table.  but we still want to record the team that's there!  don't blow the whole analysis just cuz ATL isn't there.   if no pval found, it might be because that team doens't have any games this season.  or hasn't played in the recent past.
		} else {								teamXpVal = NA }
		
		if (length(pValsRowsWithTeamY) > 0) {	teamYpVal = namesAndPvals$pVal[pValsRowsWithTeamY[1]]								#get the second p-value for the team. when running glm w/ no intercept.  cuz then the x p's are all way too small
		} else {								teamYpVal = NA	}
		
		dNumM[r, p_x_i] <- as.numeric(format(    as.numeric(round(teamYpVal, 9)),   digits=3    ))
		dNumM[r, p_y_i] <- as.numeric(format(    as.numeric(round(teamXpVal, 9)),   digits=3    ))
	}	
	return(dNumM)
}
printStuff <- function(firstLine){
	print(firstLine);print(paste("length(which(glmwt > 0)): ", length(which(glmwt > 0))));
	print("glmwt[indicesOfCurrentDate]: "); print(glmwt[indicesOfCurrentDate])
	print(paste("nobs(model): ", nobs(model)));print("model: ");print(model$call);print("");print(summary(model)$coefficients);
}




options(digits = 3)	#this isn't doing anything in the written file
options(scipen = 6)		#bias against sci notation

ignoreOtherSeasons = "true"											#default values
teamPriorGames = 10
decayType = "logistic"

timestamp = format(Sys.time(), "%H%M%S")
inputFileName = "C:\\Users\\User\\Documents\\forecasting\\data\\all\\modified_1349294556321.csv"
outputFileName = paste("C:\\Users\\User\\Documents\\forecasting\\data\\all\\r_out_", timestamp, ".csv", sep="")

setwd("C:\\Users\\User\\Documents\\forecasting\\data\\all\\")					#TODO this directory should be passed from java!									# for sink() -- for printing log file
logfileName = paste("r_log_", timestamp, ".txt", sep="")

if (length(commandArgs(TRUE)) == 5) {									#values from java via runtime call  #"+ ignoreOtherSeasons +" "+ numTeamPriorGames +" "+ decayType +" "+ rInputFileName +" "+ rOutputFileName;
	print("command args length is 5");
	if (commandArgs(TRUE)[1] == "true") ignoreOtherSeasons = TRUE;
	if (commandArgs(TRUE)[1] == "false") ignoreOtherSeasons = FALSE;
	teamPriorGames = commandArgs(TRUE)[2]
	decayType = commandArgs(TRUE)[3] 	
	inputFileName = commandArgs(TRUE)[4] 	
	outputFileName = commandArgs(TRUE)[5] 	
}
print("parameters:")
print(ignoreOtherSeasons)
print(teamPriorGames)
print(decayType)
print(inputFileName)
print(outputFileName)

#Sys.sleep(5)

d  <- read.csv(file(inputFileName))															#d for data
d$date <- as.Date(d$date , format="%m-%d-%Y")												#convert date column from string to Date format
d <- d[order(d$date),]																		#sort by date, increasing, just to be sure (was probly sorted anyway)	#d <- d[which(d$ssn == "2011"),]#d <- d[which(d$x_name == "DEN")]																	#for testing
row.names(d) <- NULL																# to ensure sequential row names for d

dTemp <- d																			#begin building matrices of original data for faster processing			
dTemp$x_name <- NULL
dTemp$y_name <- NULL
dTemp$date	 <- NULL
dNumMheader <- names(dTemp)	
dNumM <- data.matrix(dTemp)
dTemp <- data.frame( d$x_name, d$y_name, d$x_is_away )
names(dTemp) <- c( "x_name", "y_name", "x_is_away" )
dCharM <- as.matrix(dTemp); remove(dTemp)

xfai 	= which(dNumMheader == "xf_a")
yfai 	= which(dNumMheader == "yf_a")
sfei 	= which(dNumMheader == "sf_e")
tfei 	= which(dNumMheader == "tf_e")
psfxi	= which(dNumMheader == "p_sf_x")
psfyi	= which(dNumMheader == "p_sf_y")
ptfxi	= which(dNumMheader == "p_tf_x")
ptfyi	= which(dNumMheader == "p_tf_y")

uniqueDays =  unique(d$date);
for ( indexOfUniqueDays in seq_along(uniqueDays) ) {												#iterating over the indices of the set of unique days
	if (indexOfUniqueDays == 1) next																#i think this skips the day if it's the first one, so that doenstn' fail if it tries to run and there's no data.  but if we're ignoreing previous seasons, then we should skip the first day of each season!  not just the first day overall.  cuz first day of the season will have no data.
	currentDate = uniqueDays[indexOfUniqueDays]														#don't use i again!  only relevant to the set of unique days
	
	sink();	print(currentDate); sink(logfileName, append=TRUE);	print(currentDate)					#sink() unsinks -- sends output back to console
	
	indicesOfCurrentDate = which(d$date == currentDate)
	firstIndexOfCurrentDate = min(indicesOfCurrentDate)
	
	firstTeamOfCurrentDay = dCharM[firstIndexOfCurrentDate, "x_name"]							# determine how far back to look.  	#firstTeamOfCurrentDay is used to determine how many days back to look.	take the first x team of the day, and use that one to build the day's weights.  can't just use a set number of days, because some weeks have much more frequent games than others	
	r = firstIndexOfCurrentDate - 1																
	count = 0
	while (r > 0  &  count < teamPriorGames){													#loop backwards, counting occurences of team	
		if (dCharM[r, "x_name"] == firstTeamOfCurrentDay) count = count+1	
		r = r-1
	}
	if (count < teamPriorGames) next
	
	dayLookFirstI = r
	dayLookLastI = min(indicesOfCurrentDate) - 1
	
	nonZeroWtIndices = c(dayLookFirstI:dayLookLastI)											#non-zero weight indices		
	wtsLength = length(nonZeroWtIndices)
	
	glmwt <- rep(0, times=nrow(d));																	# Make Weights
	
	if (decayType == "none") {
		glmwt[nonZeroWtIndices] = 1	
	}
	if (decayType == "linear") {
		slope = 1/wtsLength
		for (i in nonZeroWtIndices)
			glmwt[i] = slope * (i-min(nonZeroWtIndices))			
	}						
	if (decayType == "exponential") {
		for (i in nonZeroWtIndices)
			glmwt[i] = exp( 0.04*(i - min(nonZeroWtIndices) - wtsLength + 1))	
	}
	if (decayType == "logistic") {	
		for (i in nonZeroWtIndices)
			glmwt[i] = 1/(1+exp(-0.2*( 1*i - min(nonZeroWtIndices) + 1 - wtsLength/4 )))	
	}	
	if (ignoreOtherSeasons) {
		currentSeason = dNumM[firstIndexOfCurrentDate, "ssn"]
		indicesOfOtherSeasons = which(dNumM[,"ssn"] != currentSeason)
		glmwt[indicesOfOtherSeasons] = 0		
	}
	
	if (sum(glmwt) == 0) next
	
	model <- glm(dNumM[, xfai] - dNumM[, yfai]	~	  dCharM[,"x_name"] + dCharM[,"y_name"] , family=gaussian, weight = glmwt) 	 	#+ dCharM[,"x_is_away"]<-- no, that doesn't help!	#spread
	#sink();	print(paste("sum of glmwt is:       ", sum(glmwt)));sink(logfileName, append=TRUE);
	dNumM[indicesOfCurrentDate, sfei] = round(fitted.values(model)[indicesOfCurrentDate],2)													#record fitted values			#removed as.character around indicesOfCurrentDate	
	namesAndPvals <- makePrettyPvalsTable()
	dNumM <- recordPValues(psfxi, psfyi)	
	printStuff("spread");
	
	model <- glm(dNumM[, xfai] + dNumM[, yfai]	~	  dCharM[,"x_name"] + dCharM[,"y_name"] , family=gaussian, weight = glmwt) 			#total 								#ATL is still lost for the y_names even if glm is run w/ no intercept
	dNumM[indicesOfCurrentDate, tfei] = round(fitted.values(model)[indicesOfCurrentDate],2)													#record fitted values			#removed as.character around indicesOfCurrentDate	
	namesAndPvals <- makePrettyPvalsTable()
	dNumM <- recordPValues(ptfxi, ptfyi)	
	printStuff("total");
	#sink();	print(debuggingIterator);sink(logfileName, append=TRUE);
	
}

m <- data.frame(d$date, dCharM, dNumM)		#m for master
names(m)[1] <- "date"
write.csv(m, file = outputFileName)
print(""); print("here is m:")
m[,]
sink()
outputFileName
