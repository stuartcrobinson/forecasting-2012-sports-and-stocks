import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import au.com.bytecode.opencsv.CSVReader;

//TODO have different nTPG values for ATS vs OU glm

//TODO - change R to calculate individual team scores.  this will allow more meaningful DA's per team.

//TODO - check and make sure that data.matrix isn't destroying data in resgressor.r

//TODO - multithread processing for r?

//TODO - cut the fat in the fucntion to make pretty pvals table

//TODO - make r_data and r_log agree on filename timestamps

//TODO - what about oct and nov of 2011???

//TODO - maybe the digest should be made from reading the completed results_full file.  in case i think of other things to try.  probably not worth it.  or, only worth it if i think of something new to try

//TODO - see if i would have been profitable in 2012 if blind to ssn 2012.  what percentage of packs that were profitable for all other years were then NOT profitable in 2012 -- my chance of getting screwed.
public class Analyzer {

	static String rInputFileName_TimeStamp = "1349294556321";
	
	static class F {		
		private static boolean isBounded(double x, double min, double max) {
			return (x >= min) && (x <= max);
		}
		public static boolean DB_passes(double db, double db_min, double db_max) {	
			return F.isBounded(db, db_min, db_max);
		}
		public static boolean p_passes(double p, double pMin, double pMax) {
			return F.isBounded(p, pMin, pMax);
		}
		public static boolean DA_passes(double[] DAs, double da_min, double da_max, int numBoundedDAs, int numDecreasingDAs) {	
			for (int i = 0; i < numBoundedDAs; i++)									//priorDAsAreBounded ?
				if ( !F.isBounded(DAs[i], da_min, da_max)  )
					return false;
			for (int i = 1; i < numBoundedDAs; i++)									//priorDAsAreDecreasing ?
				if ( !  (DAs[i-1] <= DAs[i])  )
					return false;
			return true;
		}
	}

	public static void main(String[] args) {
		final List<Boolean> 	ignoreOtherSeasons_ 		= Arrays.asList(true);								//r restriction parameters.
		final List<Integer> 	numTeamPriorGames_ 			= Arrays.asList(5, 7, 9, 11, 13, 15, 17, 19, 21, 23);
		final List<String> 		decayType_ 					= Arrays.asList("logistic", "exponential", "linear");										//"none", "linear", "exponential", "logistic"

		final List<Integer> 	numDecreasingDAs_ 			= Arrays.asList(0, 1, 2);										//java restriction parameters.
		final List<Integer> 	numRestrictedDAs_ 			= Arrays.asList(0, 1, 2, 3);
		final List<double[]> 	pMin_ 	= Arrays.asList(	
				new double[] 							{0.0, 0.0});
		final List<double[]> 	pMax_ 	= Arrays.asList(		
				new double[] 							{1.0, 1.0}, 	
				new double[] 							{0.9, 0.07}, 	
				new double[] 							{0.8, 0.05}, 	
				new double[] 							{0.7, 0.025},	
				new double[] 							{0.6, 0.01}, 
				new double[] 							{0.01, 0.008});
		final List<double[]> 	dbMin_ 	= Arrays.asList(	
				new double[] 							{0.0, 0.0},
				new double[] 							{0.5, 1.0},
				new double[] 							{1.0, 2.0},
				new double[] 							{1.5, 3.0},
				new double[] 							{2.0, 4.0});
		final List<double[]> 	dbMax_ 	= Arrays.asList(
				new double[] 							{200.0, 200.0}, 	
				new double[] 							{13.0, 25.0}, 	
				new double[] 							{10.0, 20.0},	
				new double[] 							{7.0, 10.0},  
				new double[] 							{2.0, 4.0},	
				new double[] 							{1.0, 2.0});
		final List<double[]> 	daMin_ 	= Arrays.asList(	
				new double[] 							{0.0, 0.0});		//anything besides 0 here is stupid.
		final List<double[]> 	daMax_ 	= Arrays.asList(					//maybe this metric only makes sense when applied to individual team score predictions?  glm makes same total prediction if you predict the total vs. predict the individual scores and add them
				new double[] 							{200.0, 200.0}, 	
				new double[] 							{10.0, 40.0}, 	
				new double[] 							{5.0, 20.0}, 
				new double[] 							{2.0, 4.0});

		try {
			boolean x_wins_SU, x_wins_ATS, over_wins, x_e_wins_SU, x_e_wins_ATS, over_e_wins;
			double sf_b, tf_b;
			int maxNumPastDAs = Collections.max(numRestrictedDAs_);
			int cumIts = 1, rIts = 0;
			MyFiles f = new MyFiles(rInputFileName_TimeStamp);
			ResultsPackList[] packList = new ResultsPackList[3];
			
			for (int betType : Arrays.asList(H.i.S, H.i.T)) {
				packList[betType] = new ResultsPackList();
				f.resultsStream[betType].println((new ResultsRow()).headerString);
				f.digestStream[betType].println((new ResultsRow()).headerString);
			}


			for (boolean ignoreOtherSeasons : ignoreOtherSeasons_){															//iterate through r restriction parameters
				for (int numTeamPriorGames : numTeamPriorGames_){
					for (String decayType : decayType_){

						rIts++;
						String rOutputFileName	=  f.rOutputName(rIts); 
						String rExecCmdLine = f.rExecCmdLine(ignoreOtherSeasons, numTeamPriorGames, decayType, rOutputFileName);  //"Rscript C:\\Users\\User\\workspace\\test1\\regressor.r "+ ignoreOtherSeasons +" "+ numTeamPriorGames +" "+ decayType +" "+ rInputFileName +" "+ rOutputFileName;

						Process process = Runtime.getRuntime().exec(rExecCmdLine);
						BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
						BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));
						String s = null;						
						while ((s = stdInput.readLine()) != null)																// read the output from the command 
							System.out.println(s);
						while ((s = stdError.readLine()) != null) 															// read any errors from the attempted command
							System.out.println(s);

						CSVReader csvr = new CSVReader( new FileReader(rOutputFileName));								//start handling r output data
						List<String[]> data = csvr.readAll();
						csvr.close();

						List<String> headerList = Arrays.asList(data.get(0));										//build header map
						HashMap<String, Integer> header = new HashMap<String, Integer>();
						for (int i = 0; i < headerList.size(); i++)
							header.put(headerList.get(i), i);

						for (int r = 1; r < data.size(); r++)	{												//clean the data - skip the header row
							if (	data.get(r)[header.get(H.Cols.sf_e)].equals("NA") ||													//remove row with missing data -- okay to throw out whole row cuz if spread is NA, total probably will be also.
									data.get(r)[header.get(H.Cols.tf_e)].equals("NA") ||
									data.get(r)[header.get(H.Cols.p_sf_x)].equals("NA") ||
									data.get(r)[header.get(H.Cols.p_sf_y)].equals("NA") ||
									data.get(r)[header.get(H.Cols.p_tf_x)].equals("NA") ||
									data.get(r)[header.get(H.Cols.p_tf_y)].equals("NA") ||
									(		data.get(r)[header.get(H.Cols.x_name)].equals(data.get(r-1)[header.get(H.Cols.y_name)]) 	&& 			//remove duplicated rows
											data.get(r)[header.get(H.Cols.y_name)].equals(data.get(r-1)[header.get(H.Cols.x_name)]) 	&& 	
											data.get(r)[header.get(H.Cols.date)].equals(data.get(r-1)[header.get(H.Cols.date)])	) ) {
								data.remove(r);
								r--;																									//to prevent skipping a row when one gets deleted.
							}
						}
						data.remove(0);																				//remove the header so data starts at index 0.  for consistency w/ matrix row index.

						int nr = data.size();																						//number of rows of data === number of rows to declare for upcoming data matrices
						int nTeams = 2, nBetTypes = 3;

						Date[] 			date = 		new Date[nr];								//declaring data matrices.  purpose of matrices is to transfer data from the row-based List<String[]> to a set of columns for more practical analysis.  also matrices for computer speed, and easy bracket indexing.
						Integer[]		ssn = 		new Integer[nr];		
						String[][] 		team = 		new String[nr][nTeams];							//2-d arrays to store both spread and totals value in the same object
						double[][][]	p =			new double[nr][nBetTypes][nTeams];		
						double[][]		da =		new double[nr][nBetTypes];							// DA = Difference Actual.  the difference between my estimated value and the actual value.
						double[][]		db =		new double[nr][nBetTypes];							// DB = Difference Bookee.  the difference between my estimated value and the bookee's value.
						boolean[][]		push =		new boolean[nr][nBetTypes];							
						boolean[][]		correct =	new boolean[nr][nBetTypes];							// was my prediction correct
						double[][][][] 	pastDAs = 	new double[nr][nBetTypes][nTeams][maxNumPastDAs];			// per bet type (spread or total), this is an array of an arrays of the past DAs per the team of the given row 
						boolean[]		fullDAs = 	new boolean[nr];

						for (int r=0; r < nr; r++)	{		
							List<String> rowList = Arrays.asList(data.get(r));								
							HashMap<String, String> row = new HashMap<String, String>();
							for (int c = 0; c < rowList.size(); c++)										// make the row a map with key of column name
								row.put(headerList.get(c), rowList.get(c));

							date[r] 		= (Date) H.dateformat.parse(row.get(H.Cols.date));
							ssn[r]			= Integer.valueOf(row.get(H.Cols.ssn));

							team[r][H.i.X] = row.get(H.Cols.x_name);
							team[r][H.i.Y] = row.get(H.Cols.y_name);

							p[r][H.i.S][H.i.X] =  Double.valueOf(row.get(H.Cols.p_sf_x));
							p[r][H.i.S][H.i.Y] =  Double.valueOf(row.get(H.Cols.p_sf_y)); 
							p[r][H.i.T][H.i.X] =  Double.valueOf(row.get(H.Cols.p_tf_x));
							p[r][H.i.T][H.i.Y] =  Double.valueOf(row.get(H.Cols.p_tf_y));

							double sf_a = Double.valueOf(row.get(H.Cols.xf_a)) - Double.valueOf(row.get(H.Cols.yf_a));
							double tf_a = Double.valueOf(row.get(H.Cols.xf_a)) + Double.valueOf(row.get(H.Cols.yf_a));
							double sf_e = Double.valueOf(row.get(H.Cols.sf_e));
							double tf_e = Double.valueOf(row.get(H.Cols.tf_e));
							
							try {					sf_b = Double.valueOf(row.get(H.Cols.sf_b)); 	}				//bookee values might have missing data
							catch(Exception e){		sf_b = Double.NaN;								}
							try {					tf_b = Double.valueOf(row.get(H.Cols.tf_b)); 	}
							catch(Exception e){		tf_b = Double.NaN;								}

							da[r][H.i.S] =  Math.abs(sf_e - sf_a);													//if any of these string --> number conversions fail, then i want the program to fail.
							da[r][H.i.T] =  Math.abs(tf_e - tf_a);

							db[r][H.i.S] =  Math.abs(sf_e - sf_b);		
							db[r][H.i.T] =  Math.abs(tf_e - tf_b);

							push[r][H.i.S] = sf_a == sf_b 	|| 	sf_e == sf_b	||	Double.isNaN(sf_b);				//push is used to denote games that don't have bookee data, also.  (kind of sloppy)
							push[r][H.i.T] = tf_a == tf_b 	|| 	tf_e == tf_b	||	Double.isNaN(tf_b);

							x_wins_ATS =	sf_a > sf_b;		//spread = x - y === away minus home
							over_wins =		tf_a > tf_b;
							x_wins_SU = 	sf_a > 0;

							x_e_wins_ATS =	sf_e > sf_b;
							over_e_wins =	tf_e > tf_b;
							x_e_wins_SU	= 	sf_e > 0;

							correct[r][H.i.ATS] =	x_wins_ATS	== x_e_wins_ATS;
							correct[r][H.i.OU] =	over_wins 	== over_e_wins;		
							correct[r][H.i.SU] = 	x_wins_SU 	== x_e_wins_SU;		

							fullDAs[r] = false;
						}

						for (int r=0; r < nr; r++)	{																	//fill pastDAs	
							String teamX = team[r][H.i.X];
							String teamY = team[r][H.i.Y];

							for (int betType : Arrays.asList(H.i.S, H.i.T)) {
								int daXi = 0, daYi = 0;																	

								for (int r2 = r - 1; r2 >= 0;	 r2--) {												//r2:  looping backwards from r, looking for games that the current teams played in.
									if (daXi < maxNumPastDAs){															
										if (team[r2][H.i.X].equals(teamX) || team[r2][H.i.Y].equals(teamX)){
											pastDAs[r][betType][H.i.X][daXi] = da[r2][betType];						//assign the game's DA to the specific team (x or y).  x here.
											daXi++;						
										}
									}
									if (daYi < maxNumPastDAs){
										if (team[r2][H.i.Y].equals(teamY) || team[r2][H.i.X].equals(teamY)){
											pastDAs[r][betType][H.i.Y][daYi] = da[r2][betType];
											daYi++;				
										}	
									}
								}
								if ( daXi == maxNumPastDAs && daYi == maxNumPastDAs )				
									fullDAs[r] = true;
							}
						}

						List<Integer> seasonsList = Arrays.asList(ssn);									//makes seasonsList a list of unique seasons.
						Set<Integer> seasonsLinkedHashSet = new LinkedHashSet<Integer>(seasonsList);
						seasonsList = new ArrayList<Integer>();
						seasonsList.add(0);																//this will be used to indicate that all seasons should be analyzed together
						seasonsList.addAll(seasonsLinkedHashSet);		

						for (int numBoundedDAs : numRestrictedDAs_) {
							for (int numDecreasingDAs : numDecreasingDAs_){
								for(double[] pMin : pMin_){
									for (double pMax[] : pMax_){						
										for (double[] dbMin : dbMin_) {
											for (double[] dbMax : dbMax_){
												for (double [] daMin : daMin_){
													for (double [] daMax : daMax_){	

														ResultsPack[] pack = new ResultsPack[3];	
														for (int betType : Arrays.asList(H.i.S, H.i.T))
															pack[betType] = new ResultsPack();


														for (int season : seasonsList){						//TODO make this much faster.  the data is already sitting there for all the seasons.  don't actually have to re-calculate.  this makes calculations take about 5 or 7 times longer than necessary
															int _n, sumCorrectBetGames;
															Double _pct, _profit;
															double[] pct = new double[3], profit = new double[3];
															int[] n = new int[3];
															double b = 100.0;									//bet amount (dollars)
															for (int betType : Arrays.asList(H.i.S, H.i.T)){
																_n = 0;
																sumCorrectBetGames = 0;
																_pct = Double.NaN;
																_profit = Double.NaN;
																for (int r = 0; r < nr; r++) {			//restrict by pushed games, db, da, and if there is even data there.   what if using simple glm where ATL p-values are NA? then badData[r] is true
																	if (	(ssn[r] == season || season == 0)	&&
																			!push[r][betType]					&&
																			F.p_passes( p[r][betType][H.i.X], pMin[betType], pMax[betType])	&&
																			F.p_passes( p[r][betType][H.i.Y], pMin[betType], pMax[betType])	&&
																			F.DB_passes( db[r][betType], dbMin[betType], dbMax[betType])		&&
																			fullDAs[r]															&&
																			F.DA_passes( pastDAs[r][betType][H.i.X], daMin[betType], daMax[betType], numBoundedDAs, numDecreasingDAs) &&
																			F.DA_passes( pastDAs[r][betType][H.i.Y], daMin[betType], daMax[betType], numBoundedDAs, numDecreasingDAs)	) {
																		_n++;
																		sumCorrectBetGames = sumCorrectBetGames + (correct[r][betType]? 1 : 0);				
																	}			
																}
																try {
																	_pct = (double) sumCorrectBetGames/_n;
																	_profit = (double) _n*(_pct*0.9523*b + (1-_pct)*(-1.0*b));	
																} catch (Exception e){}
																n[betType] = _n;
																profit[betType] = _profit;	
																pct[betType] = _pct;								
															}

															ResultsRow[] resultsRow = new ResultsRow[3];

															for (int betType : Arrays.asList(H.i.S, H.i.T)){
																resultsRow[betType] = new ResultsRow(ignoreOtherSeasons, numTeamPriorGames, decayType, season, numBoundedDAs, numDecreasingDAs, 
																		pMin[betType], pMax[betType], dbMin[betType], dbMax[betType], daMin[betType], daMax[betType], n[betType], pct[betType], profit[betType]);
																f.resultsStream[betType].println(resultsRow[betType].toOutputString());

																pack[betType].add(resultsRow[betType]);
															}
															cumIts++;
														}
														for (int betType : Arrays.asList(H.i.S, H.i.T))	{														
															packList[betType].addConditionally(pack[betType]);
														}
													}
												}
											}
											System.out.println("iteration: " + cumIts);
										}
									}
								}
							}
						}
					}
				}
			}
			for (int betType : Arrays.asList(H.i.S, H.i.T)){

				packList[betType].treat();
				packList[betType].printAll(f.digestStream[betType]);

				f.resultsStream[betType].close();
				f.digestStream[betType].close();
				System.out.println(f.resultsFile[betType]);
				System.out.println(f.digestFile[betType]);
			}
		} catch (Exception e) {	e.printStackTrace();}
	}
}

