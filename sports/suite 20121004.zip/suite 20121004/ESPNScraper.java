

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ESPNScraper {
    public static void main(String[] args) throws Exception {
    	
    	final List baseURLs = Arrays.asList(
    			"http://scores.espn.go.com/wnba/scoreboard",
    			"http://scores.espn.go.com/nhl/scoreboard",
    			"http://scores.espn.go.com/nba/scoreboard",
    			"",
    			"");
    			
    	
    	
    	
        WebDriver driver = new FirefoxDriver();
        
        long end = System.currentTimeMillis() + 5000;
        while (System.currentTimeMillis() < end) {
            WebElement resultsDiv = driver.findElement(By.className("gac_m"));

            if (resultsDiv.isDisplayed()) {
              break;
            }
        }
     }
}